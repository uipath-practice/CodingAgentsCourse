# Test documents for the evaluation set

Seven claim/policy pairs, one per test case. `cases.csv` says which claim goes with which policy and what is wrong with each pair.

Use these if you can't run the "Retrieve Property Claim" process. They are the same kind of documents the process generates.

All dates in these documents are day first (for example 13/09/2026 or 10.10.2026).
